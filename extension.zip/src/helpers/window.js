import Meta from 'gi://Meta';
import { Logger } from './logger.js';

function getMaximizedFlags(win) {
  let flags = 0;
  if (win.maximized_horizontally) flags |= Meta.MaximizeFlags.HORIZONTAL;
  if (win.maximized_vertically) flags |= Meta.MaximizeFlags.VERTICAL;
  return flags;
}

export class Window {
  constructor(window) {
    this._rect = window.get_frame_rect();
    this._maximized = getMaximizedFlags(window);
    this._minimized = window.minimized;
    this._workspace = window.get_workspace().index();

    // Logging only
    this._fullscreen = window.fullscreen;
    this._id = window.get_id();
    this._title = window.get_title();
  }

  toString() {
    const r = this._rect;
    return (
      `x:${r.x}, y:${r.y}, w:${r.width}, h:${r.height}, ` +
      `isMaximized:${this._maximized}, isMinimized:${this._minimized}, ` +
      `isFullscreen:${this._fullscreen}, id:${this._id}, ` +
      `title:${this._title}, workspace:${this._workspace}`
    );
  }

  restore(currentWindow) {
    this._configureWorkspace(currentWindow, this._workspace);

    if (!this._equalRect(currentWindow)) {
      if (getMaximizedFlags(currentWindow))
        currentWindow.unmaximize(Meta.MaximizeFlags.BOTH);

      this._moveResizeFrame(currentWindow);
    }

    this._setMaximized(currentWindow);
    this._setMinimized(currentWindow);
    this._logDifferences(currentWindow);
  }

  _equalRect(window) {
    const r = window.get_frame_rect();
    return (
      this._rect.x === r.x &&
      this._rect.y === r.y &&
      this._rect.width === r.width &&
      this._rect.height === r.height
    );
  }

  _moveResizeFrame(window) {
    window.move_resize_frame(
      true,
      this._rect.x,
      this._rect.y,
      this._rect.width,
      this._rect.height
    );
  }

  _setMaximized(window) {
    const current = getMaximizedFlags(window);
    if (current !== this._maximized) {
      if (this._maximized) window.maximize(this._maximized);
      else window.unmaximize(Meta.MaximizeFlags.BOTH);
    }
  }

  _setMinimized(window) {
    if (window.minimized !== this._minimized) {
      if (this._minimized) window.minimize();
      else window.unminimize();
    }
  }

  _configureWorkspace(window, workspace) {
    if (workspace !== window.get_workspace().index()) {
      window.change_workspace_by_index(workspace, true);
    }
  }

  _logDifferences(window) {
    let hasDiffs = false;

    if (window.minimized !== this._minimized) {
      Logger.debug(
        `Wrong minimized: ${window.minimized}, title:${this._title}`
      );
      hasDiffs = true;
    }

    if (getMaximizedFlags(window) !== this._maximized) {
      Logger.debug(
        `Wrong maximized: ${getMaximizedFlags(window)}, title:${this._title}`
      );
      hasDiffs = true;
    }

    if (!this._equalRect(window)) {
      const r = window.get_frame_rect();
      Logger.debug(
        `Wrong rectangle: x:${r.x}, y:${r.y}, w:${r.width}, h:${r.height}, title:${this._title}`
      );
      hasDiffs = true;
    }

    if (hasDiffs) Logger.debug(`Expecting: ${this}`);
  }
}
